﻿CREATE SCHEMA [Admin]
    AUTHORIZATION [dbo];

