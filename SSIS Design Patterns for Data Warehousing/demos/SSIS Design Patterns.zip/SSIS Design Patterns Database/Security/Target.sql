﻿CREATE SCHEMA [Target]
    AUTHORIZATION [dbo];

